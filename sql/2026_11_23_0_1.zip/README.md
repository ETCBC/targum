# The ETCBC Targum Corpus, SQL export, version 0.1, 2026-11-24

The six publication views of the ETCBC Targum Corpus, one `.sql` file each: a `CREATE TABLE`
followed by the rows as `COPY ... FROM stdin` in CSV form. Load with psql:

    psql -d yourdb -f psj_tf.sql

| file | rows | corpus |
|---|---|---|
| `cairo_genizah_tf.sql` | 33,018 | 39 Cairo Genizah fragments |
| `frag_targ_tf.sql` | 43,244 | 4 Fragment Targum recensions |
| `neofiti_base_raw_tf.sql` | 134,225 | Neofiti 1, base text (unmarked segments only) |
| `neofiti_full_tf.sql` | 169,836 | Neofiti 1, full text (every segment side by side) |
| `onqelos_tf.sql` | 116,339 | Targum Onqelos |
| `psj_tf.sql` | 143,691 | Targum Pseudo-Jonathan |
| **total** | **640,353** | one row per published word |

These are the views `tf_pipeline` serialises, so they are the publication boundary: what is here is
what the Text-Fabric dataset carries, at 64 columns per row. They are *projections* of the
underlying materialised views, not those views themselves, and the difference is deliberate. The
matviews hold editorial working state and source-lexicon identifiers that are internal and are
not published.

`word_id` and `verse_uid` are present because the view's own ordering depends on them. They are
SQL surrogate keys, they are **not** stable identifiers to cite, and they are scoped to one corpus:
the same integer means a different row in another file. Use the canonical address
(`text_text`, `book_book`, `chapter_chapter`, `verse_verse`) plus `word_uid` instead.

Provenance: `@version=0.1`, `@xmlVersion=2026-11-23`. DOI 10.5281/zenodo.21925395.
